from rich.console import Console

nxc_console = Console(soft_wrap=True, tab_size=4)
